Compiler: C++ của visual studio 2022
Sử dụng thư viện Windows.h và Console.h