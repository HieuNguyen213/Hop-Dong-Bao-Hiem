//HI�U
#include "XuatHopDong.h"
void XuatHopDong::Read_filein(ifstream& filein) {
	getline(filein, MaHopDong, ',');
	filein.seekg(1, 1);

	getline(filein, NguoiMua, ',');
	filein.seekg(1, 1);

	getline(filein, NguoiThuHuong, ',');
	filein.seekg(1, 1);

	filein >> GiaTriHopDong;

	filein.seekg(1, 1);
	filein >> ThoiHan;

	filein.seekg(1, 1);
	filein >> ngaynhap;
	this->ngay = (this->ngaynhap[0] - '0') * 10 + this->ngaynhap[1] - '0';
	this->thang = (this->ngaynhap[3] - '0') * 10 + this->ngaynhap[4] - '0';
	this->nam = (this->ngaynhap[6] - '0') * 1000 + (this->ngaynhap[7] - '0') * 100 + (this->ngaynhap[8] - '0') * 10 + this->ngaynhap[9] - '0';

	filein.seekg(1, 1);
	filein >> hoahong;

	filein.seekg(1, 1);

}
void XuatHopDong::Set_MaHopDong(string ma) {
	this->MaHopDong = ma;
}
string XuatHopDong::Get_MaHopDong() {
	return MaHopDong;
}
void XuatHopDong::Set_NguoiMua(string name1) {
	this->NguoiMua = name1;
}
string XuatHopDong::Get_NguoiMua() {
	return NguoiMua;
}
void XuatHopDong::Set_NguoiThuHuong(string name2) {
	this->NguoiThuHuong = name2;
}
string XuatHopDong::Get_NguoiThuHuong() {
	return NguoiThuHuong;
}
void XuatHopDong::Set_GiaTriHopDong(float giatri) {
	this->GiaTriHopDong = giatri;
}
float XuatHopDong::Get_GiaTriHopDong() {
	return GiaTriHopDong;
}
void XuatHopDong::Set_hoahong(float hoahong) {
	this->hoahong = hoahong;
}
float XuatHopDong::Get_hoahong() {
	return hoahong;
}
void XuatHopDong::Set_ngaynhap(string ngaynhap) {
	this->ngaynhap = ngaynhap;
}
string XuatHopDong::Get_ngaynhap() {
	return ngaynhap;
}
void XuatHopDong::Set_ThoiHan(int thoihan) {
	this->ThoiHan = thoihan;
}
int XuatHopDong::Get_ThoiHan() {
	return ThoiHan;
}
void XuatHopDong::Xuat() {
	cout << setw(11) << MaHopDong << setfill(' ') << "|" << setw(15) << NguoiMua << setfill(' ') << "|" << setw(21) << NguoiThuHuong << setfill(' ') << "|" << setw(16) << (size_t)GiaTriHopDong << setfill(' ') << "|" << setw(8) << " " << right << setw(2) << setfill('0') << this->ngay << "/" << setw(2) << setfill('0') << this->thang << "/" << setw(4) << this->nam << "|" << setfill(' ') << setw(17) << (size_t)ThoiHan << setfill(' ') << "|" << setw(10) << hoahong;
}
void HopDongCoBan::Read_filein(ifstream& filein) {
	XuatHopDong::Read_filein(filein);
	filein >> TienGiuLai;
}
void HopDongCoBan::Xuat() {
	XuatHopDong::Xuat();
	cout << "|" << setw(17) << (size_t)TienGiuLai << setfill(' ') << endl;
}
void HopDongCoBan::Set_TienGiuLai() {
	this->TienGiuLai = this->Get_GiaTriHopDong() * this->Get_hoahong() / 100;
}
float HopDongCoBan::Get_TienGiuLai() {
	return TienGiuLai;
}
void HopDongNangCao::Xuat() {
	XuatHopDong::Xuat();
	cout << "|" << setw(17) << (size_t)TienGiuLai << setfill(' ') << endl;
}
void HopDongNangCao::Read_filein(ifstream& filein) {
	XuatHopDong::Read_filein(filein);
	filein >> TienGiuLai;
}
void HopDongNangCao::Set_TienGiuLai() {
	this->TienGiuLai = this->Get_GiaTriHopDong() * this->Get_hoahong() / 100 + 1000000;
}
float HopDongNangCao::Get_TienGiuLai() {
	return TienGiuLai;
}
HopDongCoBan::~HopDongCoBan() {}
HopDongNangCao::~HopDongNangCao() {}
