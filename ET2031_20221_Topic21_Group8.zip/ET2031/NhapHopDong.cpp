//NGA
#include "NhapHopDong.h"
float NhapHopDong::a = 10;
float NhapHopDong::b = 17;
NhapHopDong::NhapHopDong() {}
NhapHopDong::~NhapHopDong() {}
void NhapHopDong:: Nhap() {
	gotoXY(50, 6);
	cout << "Nhap ma hop dong: ";
	cin >> MaHopDong;
	for (int i = 0; i < 2; i++) {
		if ('a' <= MaHopDong[i] && MaHopDong[i] <= 'z') {
			MaHopDong[i] = MaHopDong[i] - 32;
		}
	}
	gotoXY(50, 7);
	cout << "Nhap ten nguoi mua: ";
	cin.ignore();
	getline(cin, NguoiMua);
	gotoXY(50, 8);
	cout << "Nhap ten nguoi thu huong: ";
	getline(cin, NguoiThuHuong);
	gotoXY(50, 9);
	cout << "Nhap gia tri hop dong: ";
	cin >> GiaTriHopDong;
	gotoXY(50, 10);
	cout << "Nhap Thoi han hop dong: ";
	cin >> ThoiHan;
	gotoXY(50, 13);
	cout << "Ngay nhap hop dong: ";
	cin.ignore();
	getline(cin, ngaynhap);
}
string NhapHopDong::Get_MaHopDong() {
	return MaHopDong;
}

HopDongCoBan1::HopDongCoBan1(){}
void HopDongCoBan1::Set_hoahong() {
	this->hoahong = a;
}
void HopDongCoBan1::Set_hoahong(float cb) {
	this->hoahong = cb;
}
float HopDongCoBan1::Get_hoahong() {
	return hoahong;
}
void HopDongCoBan1::Set_TienGiuLai() {
	this->TienGiuLai = this->GiaTriHopDong * this->hoahong / 100;
}
istream& operator>>(istream& input, HopDongCoBan1& hd) {
	gotoXY(50, 6);
	cout << "Nhap ma hop dong: ";
	cin >> hd.MaHopDong;
	for (int i = 0; i < 2; i++) {
		if ('a' <= hd.MaHopDong[i] && hd.MaHopDong[i] <= 'z') {
			hd.MaHopDong[i] = hd.MaHopDong[i] - 32;
		}
	}
	gotoXY(50, 7);
	cout << "Nhap ten nguoi mua: ";
	cin.ignore();
	getline(cin, hd.NguoiMua);
	gotoXY(50, 8);
	cout << "Nhap ten nguoi thu huong: ";
	getline(cin, hd.NguoiThuHuong);
	gotoXY(50, 9);
	cout << "Nhap gia tri hop dong: ";
	cin >> hd.GiaTriHopDong;
	gotoXY(50, 10);
	cout << "Nhap Thoi han hop dong: ";
	cin >> hd.ThoiHan;
	hd.Set_hoahong();
	hd.Set_TienGiuLai();
	gotoXY(50, 11);
	cout << "% hoa hong: " << hd.hoahong << endl;
	gotoXY(50, 12);
	cout << "Tien giu lai: " << (size_t)hd.TienGiuLai << endl;
	gotoXY(50, 13);
	cout << "Ngay nhap hop dong: ";
	cin.ignore();
	getline(cin, hd.ngaynhap);
	return input;
}
ostream& operator<<(ostream& output, HopDongCoBan1 hd) {
	return output << hd.MaHopDong << ", " << hd.NguoiMua << ", " << hd.NguoiThuHuong << ", " << (size_t)hd.GiaTriHopDong << ", " << hd.ThoiHan << ", " << hd.ngaynhap << ", " << hd.hoahong << ", " << (size_t)hd.TienGiuLai << endl;
}
HopDongCoBan1::~HopDongCoBan1() {}

HopDongNangCao1::HopDongNangCao1() {}
void HopDongNangCao1::Set_hoahong() {
	this->hoahong = b;
}
void HopDongNangCao1::Set_hoahong(float nc) {
	this->hoahong = nc;
}
float HopDongNangCao1::Get_hoahong() {
	return hoahong;
}
void HopDongNangCao1::Set_TienGiuLai() {
	this->TienGiuLai = this->GiaTriHopDong * this->hoahong / 100 + 1000000;
}
istream& operator>>(istream& input, HopDongNangCao1& hd) {
	gotoXY(50, 6);
	cout << "Nhap ma hop dong: ";
	cin >> hd.MaHopDong;
	for (int i = 0; i < 2; i++) {
		if ('a' <= hd.MaHopDong[i] && hd.MaHopDong[i] <= 'z') {
			hd.MaHopDong[i] = hd.MaHopDong[i] - 32;
		}
	}
	gotoXY(50, 7);
	cout << "Nhap ten nguoi mua: ";
	cin.ignore();
	getline(cin, hd.NguoiMua);
	gotoXY(50, 8);
	cout << "Nhap ten nguoi thu huong: ";
	getline(cin, hd.NguoiThuHuong);
	gotoXY(50, 9);
	cout << "Nhap gia tri hop dong: ";
	cin >> hd.GiaTriHopDong;
	gotoXY(50, 10);
	cout << "Nhap Thoi han hop dong: ";
	cin >> hd.ThoiHan;
	hd.Set_hoahong();
	hd.Set_TienGiuLai();
	gotoXY(50, 11);
	cout << "% hoa hong: " << hd.hoahong << endl;
	gotoXY(50, 12);
	cout << "Tien giu lai: " << (size_t)hd.TienGiuLai << endl;
	gotoXY(50, 13);
	cout << "Ngay nhap hop dong: ";
	cin.ignore();
	getline(cin, hd.ngaynhap);
	return input;
}
ostream& operator<<(ostream& output, HopDongNangCao1 hd) {
	return output << hd.MaHopDong << ", " << hd.NguoiMua << ", " << hd.NguoiThuHuong << ", " << (size_t)hd.GiaTriHopDong << ", " << hd.ThoiHan << ", " << hd.ngaynhap << ", " << hd.hoahong << ", " << (size_t)hd.TienGiuLai << endl;
}
HopDongNangCao1::~HopDongNangCao1() {}
