﻿#include "Function.h"
#include<iostream>
#include<fstream>
#include<conio.h>
#include<math.h>
using namespace std;
#define TUONG_TREN 5
#define TUONG_DUOI 30
#define TUONG_PHAI 125
#define TUONG_TRAI 45
#define Maunen 123
#define Mauchu 135
typedef char str[100];
str thaotac[7] = { "Nhap thong tin hop dong",
"Xuat danh sach hop dong", "Tim hop dong",
"Sua hop dong", "Thong ke cac hop dong bao hiem ban duoc trong mot khoang thoi gian",
"Thong ke so tien cong ty thu nhan do ban bao hiem trong mot khoang thoi gian",
"Ket thuc" };

str thaotac2[4] = { "Sua thong tin hop dong", "Xoa hop dong", "Sua lai % hoa hong", "Quay lai" };
enum TRANGTHAI { UP, DOWN, LEFT, RIGHT, ENTER, BACK };

str thaotac3[6] = { "Sua ten nguoi mua", "Sua ten nguoi thu huong",
"Sua gia tri hop dong", "Sua thoi han", "Quay lai" };

str thaotac4[3] = { "Nhap moi danh sach", "Them danh sach", "Quay lai" };

str thaotac5[2] = { "YES", "NO" };

str thaotac6[2] = { "Thu lai", "Quay lai" };
TRANGTHAI key(int z) {
	if (z == 224) {
		char c;
		c = _getch();
		if (c == 72) {
			return UP;
		}
		if (c == 80) {
			return DOWN;
		}
		if (c == 77) {
			return RIGHT;
		}
		if (c == 75) {
			return LEFT;
		}
	}
	else if (z == 13) {
		return ENTER;
	}
}
//NGA
int Set_Date(string comp)
{
	int ngay, thang, nam;
	/*Vì đây đang là một chuỗi nên cần chuyển thành số*/
	ngay = comp[0] * 10 + comp[1];
	thang = comp[3] * 10 + comp[4];
	nam = comp[6] * 1000 + comp[7] * 100 + comp[8] * 10 + comp[9];
	/*ví dụ 25/09/2003 sẽ chuyển thành số 20030925*/
	return (nam * 10000 + thang * 100 + ngay);
}
//NGA
void Function::Save() {
	gotoXY(30, 4);
	TextColor(135);
	cout << "Loai hop dong can nhap: ";
	string loai;
	getline(cin, loai);
	/*chuyển đổi chữ thường thành chữ hoa*/
	for (int i = 0; i < 2; i++) {
		if ('a' <= loai[i] && loai[i] <= 'z') {
			loai[i] = loai[i] - 32;
		}
	}
	int n;
	gotoXY(30, 5);
	cout << "So hop dong can nhap: ";
	cin >> n;
	/*mở file ds.txt ra rồi ghi n vào*/
	ofstream fileout("ds.txt");
	fileout << n << endl;
	/*nếu kí tự đầu tiên của loại hợp đồng là 'C' tức là hợp đồng cơ bản thì sẽ khai báo đối tượng tương ứng*/
	if (loai[0] == 'C') {
		HopDongCoBan1* hd;
		//cấp bộ nhớ cho hd (chính là n: số hợp đồng cần nhập bên trên)
		hd = new HopDongCoBan1[n];
		for (int i = 0; i < n; i++) {
		/*label. Nếu nhập sai thì sẽ quay lại để nhập lại*/
		nhap1:
			system("cls");
			gotoXY(50, 2);
			TextColor(132);
			cout << "=== Nhap moi hop dong ===";
			TextColor(135);
			gotoXY(30, 4);
			cout << "Loai hop dong can nhap: " << loai;
			gotoXY(30, 5);
			cout << "So hop dong can nhap: " << n << endl;
			gotoXY(30, 6);
			cout << "Hop dong thu " << i + 1 << ":";
			//thực hiện nhập hợp đồng thứ i
			cin >> hd[i];
			/*Kiểm tra xem mã hợp đồng nhập vào có trùng với loại hợp đồng đã nhập bên trên không.
			Ví dụ, loại hợp đồng cần nhập là CB (cơ bản) nhưng mã lại nhập vào NC1 (nâng cao 1) thì sẽ báo lỗi.
			Tương tự với hợp đồng nâng cao bên dưới*/
			if (hd[i].Get_MaHopDong()[0] != 'C') {
				TextColor(132);
				gotoXY(50, 15);
				cout << "Ma hop dong khong khop!";
				gotoXY(50, 16);
				cout << "Vui long nhap lai!";
				system("pause");
				goto nhap1;
			}
			/*cho chạy từ i >= 1 vì đây là nhập mới danh sách(nhập vào 1 file trống),
		    Nếu xét từ i=0 thì trước đó chưa có hợp đồng nào được lưu, chương trình sẽ không đọc được
		    => phải xét từ hợp đồng thứ 2 trở đi, tức i>=1. CHương trình sẽ đọc dữ liệu được lưu trong file để
			kiểm tra xong mã hợp đồng trước đó đã được nhập chưa, mã hợp đồng sau có trùng với mã hợp đồng trước không */
			if (i >= 1) {
				/*khai báo DS để đọc thông tin các hợp đồng đã được lưu trước hợp đồng thứ i cần xét*/
				XuatHopDong* DS;
				DS = new XuatHopDong[i];
				ifstream filein;
				filein.open("ds.txt", ios_base::in);
				XuatHopDong* x = NULL;
				//biến m này chỉ có tác dụng đọc số đầu tiên của file ds.txt
				int m;
				filein >> m;
				/*chỉ xét vòng lặp chạy từ 0 đến < i vì chỉ cần xét số hợp đồng ở trước hợp đồng thứ i.
			    Ví dụ, nhập mới vào hợp đồng thứ 3 (i=2) thì chỉ cần xét 2 hợp đồng đứng trước là
			    hợp đồng thứ 1 (j=0) và 2 (j=1) để xem có trùng mã hợp đồng với hợp đồng thứ 3 không. */
				for (int j = 0; j < i; j++) {
					//biến c có tác dụng đọc kí tự đầu tiên của mã hợp đồng
					char c;
					filein >> c;
					filein.seekg(-1, 1);
					if (c == 'C') {
						//nếu kí tự đầu tiên là 'C' thì đó là hợp đồng cơ bản => cấp bộ nhớ tương ứng.
						//Tương tự nếu kí tự đó là 'N'
						x = new HopDongCoBan();
						x->Read_filein(filein);
					}
					else if (c == 'N') {
						x = new HopDongNangCao();
						x->Read_filein(filein);
					}
					/*x đã được lưu dữ liệu từ file sẽ gán sang DS*/
					DS[j] = *x;
				}
				filein.close();
				for (int j = 0; j < i; j++) {
					//ví dụ nếu hợp đồng thứ 1(j=0) trùng mã với hợp đồng thứ 2(i=1) thì thực hiện lệnh bên trong if
					if ((DS + j)->Get_MaHopDong() == (hd + i)->Get_MaHopDong()) {
						TextColor(132);
						gotoXY(50, 15);
						cout << "Ma hop dong da ton tai!";
						gotoXY(50, 16);
						cout << "Vui long nhap lai!";
						cout << endl;
						system("pause");
						/*quay lại label nhap1 để tiến hành nhập lại*/
						goto nhap1;
					}
				}
				delete[]DS;
			}
			fileout << hd[i];
			cout << "\n";
			cout << "\n";
		}
		fileout.close();
		delete[]hd;
	}
	/*nếu kí tự đầu tiên của loại hợp đồng là 'N' tức là hợp đồng nâng cao thì sẽ khai báo đối tượng tương ứng*/
	if (loai[0] == 'N') {
		HopDongNangCao1* hd;
		hd = new HopDongNangCao1[n];
		for (int i = 0; i < n; i++) {
		nhap2:
			system("cls");
			gotoXY(50, 2);
			TextColor(132);
			cout << "=== Nhap moi hop dong ===";
			TextColor(135);
			gotoXY(30, 4);
			cout << "Loai hop dong can nhap: " << loai;
			gotoXY(30, 5);
			cout << "So hop dong can nhap: " << n << endl;
			gotoXY(30, 6);
			cout << "Hop dong thu " << i + 1 << ":";
			cin >> hd[i];
			if (hd[i].Get_MaHopDong()[0] != 'N') {
				TextColor(132);
				gotoXY(50, 15);
				cout << "Ma hop dong khong khop!";
				gotoXY(50, 16);
				cout << "Vui long nhap lai!";
				system("pause");
				goto nhap2;
			}
			if (i >= 1) {
				XuatHopDong* DS;
				DS = new XuatHopDong[i];
				ifstream filein;
				filein.open("ds.txt", ios_base::in);
				XuatHopDong* x = NULL;
				int m;
				filein >> m;
				for (int j = 0; j < i; j++) {
					char c;
					filein >> c;
					filein.seekg(-1, 1);
					if (c == 'C') {
						x = new HopDongCoBan();
						x->Read_filein(filein);
					}
					else if (c == 'N') {
						x = new HopDongNangCao();
						x->Read_filein(filein);
					}
					DS[j] = *x;
				}
				filein.close();
				for (int j = 0; j < i; j++) {
					if ((DS + j)->Get_MaHopDong() == (hd + i)->Get_MaHopDong()) {
						TextColor(132);
						gotoXY(50, 15);
						cout << "Ma hop dong da ton tai!";
						gotoXY(50, 16);
						cout << "Vui long nhap lai!";
						cout << endl;
						system("pause");
						goto nhap2;
					}
				}
				delete[]DS;
			}
			fileout << hd[i];
			cout << "\n";
			cout << "\n";
		}
		fileout.close();
		delete[]hd;
	}
}
//NGA
void Function::Add(int& n)
{
	/*Truyền vào biến n: chỉ số hợp đồng đã được lưu trong file*/
	system("cls");
	gotoXY(50, 2);
	TextColor(132);
	cout << "=== Nhap them hop dong ===";
	TextColor(135);
	gotoXY(30, 4);
	cout << "Loai hop dong can them: ";
	string loai;
	getline(cin, loai);
	for (int i = 0; i < 2; i++) {
		if ('a' <= loai[i] && loai[i] <= 'z') {
			loai[i] = loai[i] - 32;
		}
	}
	gotoXY(30, 5);
	cout << "So hop dong can them: ";
	int m;
	TextColor(135);
	cin >> m;
	int p = m + n;
	/*Mở fiel để GHI*/
	fstream fileout;
	fileout.open("ds.txt", ios_base::out | ios_base::in);
	fileout << p;
	fileout.close();
	/*Nếu loại hợp đồng là CB thì gọi đối tượng rồi cấp bộ nhớ tương ứng. Tương tự với phần Save ở trên*/
	if (loai[0] == 'C') {
		HopDongCoBan1* addhd;
		addhd = new HopDongCoBan1[m];
		fstream fileout;
		fileout.open("ds.txt", ios_base::app);
		/*Phần này không xét từ i>=1 mà sẽ xét luôn từ đầu vì đây là nhập vào 1 file đã có dữ liệu*/
		for (int i = 0; i < m; i++) {
		nhap:
			clrscr();
			gotoXY(50, 2);
			TextColor(132);
			cout << "=== Nhap them hop dong ===";
			TextColor(135);
			gotoXY(30, 4);
			cout << "Loai hop dong can them: " << loai;
			gotoXY(30, 5);
			cout << "So hop dong can them: " << m;
			gotoXY(30, 6);
			cout << "Hop dong thu " << i + 1 << ":";
			cin >> addhd[i];
			if (addhd[i].Get_MaHopDong()[0] != 'C') {
				TextColor(132);
				gotoXY(50, 15);
				cout << "Ma hop dong khong khop!";
				gotoXY(50, 16);
				cout << "Vui long nhap lai!";
				system("pause");
				goto nhap;
			}
			XuatHopDong* DS;
			DS = new XuatHopDong[n + i];
			ifstream filein;
			filein.open("ds.txt", ios_base::in);
			XuatHopDong* x = NULL;
			int dem;
			filein >> dem;
			for (int j = 0; j < n + i; j++) {
				char c;
				filein >> c;
				filein.seekg(-1, 1);
				if (c == 'C') {
					x = new HopDongCoBan();
					x->Read_filein(filein);
				}
				if (c == 'N') {
					x = new HopDongNangCao();
					x->Read_filein(filein);
				}
				DS[j] = *x;
			}
			filein.close();
			for (int j = 0; j < n + i; j++) {
				if ((DS + j)->Get_MaHopDong() == (addhd + i)->Get_MaHopDong()) {
					TextColor(132);
					gotoXY(50, 15);
					cout << "Ma hop dong da ton tai!";
					gotoXY(50, 16);
					cout << "Vui long nhap lai!";
					cout << endl;
					system("pause");
					system("cls");
					gotoXY(50, 2);
					cout << "=== Nhap them hop dong ===";
					goto nhap;
				}
			}
			fileout << addhd[i];
			cout << "\n";
			cout << "\n";
			delete[]DS;
		}
		fileout.close();
		delete[]addhd;
	}
	if (loai[0] == 'N') {
		HopDongNangCao1* addhd;
		addhd = new HopDongNangCao1[m];
		fstream fileout;
		fileout.open("ds.txt", ios_base::app);
		for (int i = 0; i < m; i++) {
		nhap2:
			clrscr();
			gotoXY(50, 2);
			TextColor(132);
			cout << "=== Nhap them hop dong ===";
			TextColor(135);
			gotoXY(30, 4);
			cout << "Loai hop dong can them: " << loai;
			gotoXY(30, 5);
			cout << "So hop dong can them: " << m;
			gotoXY(30, 6);
			cout << "Hop dong thu " << i + 1 << ":";
			cin >> addhd[i];
			if (addhd[i].Get_MaHopDong()[0] != 'N') {
				TextColor(132);
				gotoXY(50, 15);
				cout << "Ma hop dong khong khop!";
				gotoXY(50, 16);
				cout << "Vui long nhap lai!";
				system("pause");
				goto nhap2;
			}
			//DS dùng để đọc thông tin các hợp đồng đã được lưu từ trước hợp đồng i cần xét
			/*phần này không xét từ i>=1 mà sẽ xét ngay khi nhập thêm hợp đồng vào
			vì trước khi nhập thêm hợp đồng thì file ds.txt đã tồn tại dữ liệu được nhập từ hàm SAVE().
			Ví dụ, trước đã có 5 hợp đồng, giờ nhập thêm 2 hợp đồng nữa thì sẽ cần đọc mã hợp đồng
			của 5 hợp đồng kia để xem có trùng mã vs 2 hợp đồng nhập thêm không*/
			XuatHopDong* DS;
			//biến n chỉ số hợp đồng có sẵn trong file ds.txt (trước khi thêm hợp đồng)
			//được truyền vào hàm để cấp phát bộ nhớ
			DS = new XuatHopDong[n + i];
			ifstream filein;
			filein.open("ds.txt", ios_base::in);
			XuatHopDong* x = NULL;
			int dem;
			filein >> dem;
			/*Cho chạy từ j=0 đến j<n+i vì trước đó trong file đã có sẵn n hợp đồng*/
			for (int j = 0; j < n + i; j++) {
				char c;
				filein >> c;
				filein.seekg(-1, 1);
				if (c == 'C') {
					x = new HopDongCoBan();
					x->Read_filein(filein);
				}
				if (c == 'N') {
					x = new HopDongNangCao();
					x->Read_filein(filein);
				}
				DS[j] = *x;
			}
			filein.close();
			for (int j = 0; j < n + i; j++) {
				if ((DS + j)->Get_MaHopDong() == (addhd + i)->Get_MaHopDong()) {
					TextColor(132);
					gotoXY(50, 15);
					cout << "Ma hop dong da ton tai!";
					gotoXY(50, 16);
					cout << "Vui long nhap lai!";
					cout << endl;
					system("pause");
					system("cls");
					gotoXY(50, 2);
					cout << "=== Nhap them hop dong ===";
					goto nhap2;
				}
			}
			fileout << addhd[i];
			cout << "\n";
			cout << "\n";
			delete[]DS;
		}
		fileout.close();
		delete[]addhd;
	}
}
//HIEU
void Function::Read(XuatHopDong* ds[], int& n) {
	/*truyền vào mảng đến tiến hành lưu dữ liệu vào mảng, n là số hợp đồng*/
	ifstream filein;
	filein.open("ds.txt", ios_base::in);
	XuatHopDong* x = NULL;
	filein >> n;
	/*Cho chạy từ i=0 đến n vì ở trên đã mở file ra đọc và đọc được số hợp đồng
	hiện có trong file là n*/
	for (int i = 0; i < n; i++) {
		/*Đọc kí tự đầu tiên, tuỳ theo loại hợp đồng để cấp bộ nhớ tương ứng rồi tiến hành đọc*/
		char c;
		filein >> c;
		filein.seekg(-1, 1);
		if (c == 'C') {
			x = new HopDongCoBan();
			x->Read_filein(filein);
		}
		else if (c == 'N') {
			x = new HopDongNangCao();
			x->Read_filein(filein);
		}
		ds[i] = x;
	}
}
void Function::Menu() {
	int n;
	n = 0;
	XuatHopDong* ds[100];
	HopDongCoBan1 CB;
	HopDongNangCao1 NC;
	int tt = 0;
	int* mau = new int[7];
	for (int i = 0; i < 7; i++)
		mau[i] = Mauchu;
	mau[0] = Maunen;
back:
	system("color 80");
	while (1) {
		clrscr();
		//biến này để kiểm tra
		bool value = true;
		int a = 4;
		TextColor(132);
		gotoXY(46, 2);
		cout << "\t\t === MENU ===" << endl;
		for (int i = 0; i < 7; i++) {
			TextColor(mau[i]);
			gotoXY(40, a);
			cout << thaotac[i] << endl;
			a = a + 2;
		}
		TextColor(132);
		gotoXY(46, 18);
		cout << "\t\t === END ===" << endl;
		int z = _getch();
		TRANGTHAI trangthai = key(z);
		switch (trangthai) {
		case UP:
			if (tt == 0) {
				tt = 6;
			}
			else {
				tt--;
			}
			break;
		case DOWN:
			if (tt == 6) {
				tt = 0;
			}
			else {
				tt++;
			}
			break;
		case ENTER:
			////1. Them hop dong (NGA)
			if (tt == 0) {
				int tt4 = 0;
				int* mau = new int[3];
				for (int i = 0; i < 3; i++)
					mau[i] = Mauchu;
				mau[0] = Maunen;
				system("color 80");
				while (1) {
					clrscr();
					TextColor(132);
					gotoXY(50, 2);
					cout << "=== NHAP THONG TIN HOP DONG ===" << endl << endl;
					int a = 4;
					for (int i = 0; i < 3; i++) {
						TextColor(mau[i]);
						gotoXY(52, a);
						cout << thaotac4[i] << endl;
						a = a + 2;
					}
					int z = _getch();
					TRANGTHAI trangthai4 = key(z);
					switch (trangthai4) {
					case UP:
						if (tt4 == 0) {
							tt4 = 2;
						}
						else {
							tt4--;
						}
						break;
					case DOWN:
						if (tt4 == 2) {
							tt4 = 0;
						}
						else {
							tt4++;
						}
						break;
					case ENTER:
						if (tt4 == 0) {
							system("cls");
							gotoXY(50, 2);
							TextColor(132);
							cout << "=== Nhap moi hop dong ===";
							/*Gọi phương thức Save*/
							Save();
							system("pause");
						}
							if (tt4 == 1) {
								//mở file ra để đọc số hợp đồng có trong file để truyền vào phương thức Add
								ifstream filein;
								filein.open("ds.txt", ios_base::in);
								filein >> n;
								filein.close();
								Add(n);
								system("pause");
							}
						if (tt4 == 2) {
							//quay trở lại label back
							goto back;
						}
					}
					for (int i = 0; i < 3; i++)
						mau[i] = Mauchu;
					mau[tt4] = Maunen;
				}
			}
			//2. xuất toàn bộ hợp đồng (HIẾU)
			if (tt == 1) {
				//nếu câu lệnh này được gọi thì value sẽ chuyển thành true
				value = false;
				clrscr();
				system("color 80");
				/*gọi phương thức Read, truyền vào mảng và n*/
				Read(ds, n);
				clrscr();
				gotoXY(50, 2);
				TextColor(132);
				cout << "=== Danh sach hop dong ===" << endl << endl;
				TextColor(Mauchu);
				/*Phần này để tạo bảng hiển thị cho dễ nhìn*/
				cout << "Ma hop dong" << "|" << " Ten nguoi mua " << "|" << " Ten nguoi thu huong " << "|" << "Gia tri hop dong" << "|" << "Ngay nhap hop dong" << "|" << "Thoi han hop dong" << "|" << "% hoa hong" << "|" << "Tien duoc giu lai" << endl;
				for (int i = 0; i < 126; i++) {
					cout << "_";
					if (i == 10 || i == 25 || i == 46 || i == 62 || i == 80 || i == 97 || i == 107) {
						cout << "|";
					}
				}
				cout << endl;
				/*với n là số hợp đồng đã được đọc và ghi vào từ file ở bên trên
				cho vòng lặp chạy và in ra lần lượt*/
				for (int i = 0; i < n; i++) {
					ds[i]->Xuat();
				}
				cout << endl;
				system("pause");
				system("cls");
			}
			//3. tìm kiếm hợp đồng (HIẾU)
			if (tt == 2) {
				/*Lệnh if này để kiểm tra xem hợp đồng đã được xuất hay chưa.
				Nếu trước khi thực hiện lệnh này hợp đồng chưa được xuất, tức là chưa ghi dữ liệu
				từ file vào chương trình, value là false thì sẽ tiến hành đọc file để ghi dữ liệu 
				từ file vào chương trình nhờ phương thức Read*/
				if (value) {
					Read(ds, n);
					value = false;
				}
			nhapthoihan:
				system("cls");
				gotoXY(50, 2);
				cout << "=== Tim hop dong theo thoi han ===";
				int a;
				TextColor(135);
				gotoXY(56, 4);
				cout << "Nhap vao thoi han: ";
				cin >> a;
				cout << endl << endl;
				int i = 0;
				int count = 0;
				if (a > 0) {
					cout << "Ma hop dong" << "|" << " Ten nguoi mua " << "|" << " Ten nguoi thu huong " << "|" << "Gia tri hop dong" << "|" << "Ngay nhap hop dong" << "|" << "Thoi han hop dong" << "|" << "% hoa hong" << "|" << "Tien duoc giu lai" << endl;
					for (int i = 0; i < 126; i++) {
						cout << "_";
						if (i == 10 || i == 25 || i == 46 || i == 62 || i == 80 || i == 97 || i == 107) {
							cout << "|";
						}
					}
					cout << endl;
					for (int i = 0; i < n; i++) {
						//nếu thời hạn của hợp đồng thứ i trùng với thời hạn nhập vào
						//thì xuất hợp đồng đó ra. Đồng thời biến count tăng lên
						if (ds[i]->Get_ThoiHan() == a) {
							ds[i]->Xuat();
							count++;
						}
					}
					/*Nếu count=0 tức là không có hợp đồng nào trùng với thời hạn đã nhập
					, chương trình sẽ báo danh sách trống*/
					if (count == 0) {
						gotoXY(53, 9);
						TextColor(132);
						cout << "DANH SACH TRONG!" << endl << endl;
					}
					cin.ignore();
					cout << endl << endl;
					system("pause");
				}
				//Vì thời hạn không âm nên nếu nhập vào thời hạn < 0 sẽ báo lỗi và yêu cầu nhập lại
				if (a <= 0) {
					gotoXY(56, 7);
					TextColor(132);
					cout << "THOI HAN KHONG HOP LE!";
					gotoXY(56, 8);
					cout << "VUI LONG NHAP LAI!" << endl << endl;
					cin.ignore();
					system("pause");
					goto nhapthoihan;
				}
			}
			//4. Sửa hợp đồng (HIẾU)
			if (tt == 3) {
				int tt2 = 0;
				int* mau = new int[4];
				for (int i = 0; i < 4; i++)
					mau[i] = Mauchu;
				mau[0] = Maunen;
			back2:
				system("color 80");
				while (1) {
					bool value = true;
					clrscr();
					gotoXY(50, 2);
					TextColor(132);
					cout << "=== Sua hop dong ===" << endl;
					int line = 4;
					for (int i = 0; i < 4; i++) {
						TextColor(mau[i]);
						gotoXY(50, line);
						cout << thaotac2[i] << endl;
						line = line + 2;
					}
					int z = _getch();
					TRANGTHAI trangthai2 = key(z);
					switch (trangthai2) {
					case UP:
						if (tt2 == 0) {
							tt2 = 3;
						}
						else {
							tt2--;
						}
						break;
					case DOWN:
						if (tt2 == 3) {
							tt2 = 0;
						}
						else {
							tt2++;
						}
						break;
					case ENTER:
						if (tt2 == 0) {
							int n;
							XuatHopDong* danhsach[100];
							Read(danhsach, n);
							/*Tiến hành mở file để đọc số hợp đồng rồi lưu vào n*/
							ifstream filein;
							filein.open("ds.txt", ios_base::in);
							filein >> n;
							//Khai báo 2 loại đối tượng rồi cấp phát động (chính là n chỉ số hợp đồng)
							HopDongCoBan* x;
							HopDongNangCao* y;
							x = new HopDongCoBan[n];
							y = new HopDongNangCao[n];
							/*phần này để tiến hành lưu dữ liệu vào loại đối tượng tương ứng
							hợp đồng cơ bản lưu vào x, hợp đồng nâng cao lưu vào y*/
							for (int i = 0; i < n; i++) {
								char c;
								filein >> c;
								filein.seekg(-1, 1);
								if (c == 'C') {
									(x + i)->Read_filein(filein);
								}
								if (c == 'N') {
									(y + i)->Read_filein(filein);
								}
							}
							filein.close();
							/*biến find này có tác dụng kiểm tra, nếu tìm thầy hợp đồng sẽ
							chuyển thành true*/
							bool find = false;
						nhapma1:
							system("cls");
							gotoXY(50, 2);
							TextColor(132);
							cout << "=== Sua hop dong ===" << endl;
							gotoXY(46, 3);
							TextColor(135);
							cout << "Nhap ma hop dong can sua: ";
							string ma;
							getline(cin, ma);
							for (int i = 0; i < 2; i++) {
								if ('a' <= ma[i] && ma[i] <= 'z') {
									ma[i] = ma[i] - 32;
								}
							}
							/*Xét kí tự đầu của ma, nếu là 'C' tức là cần sửa hợp đồng cơ bản. còn là 'N'
							thì là cần sửa hợp đồng nâng cao*/
							if (ma[0] == 'C') {
								/*Tiến hành xét tất cả hợp đồng, nếu tìm được mã hợp đồng cơ bản nào trùng
								với ma thì thực hiện các câu lệnh biên dưới*/
								for (int i = 0; i < n; i++) {
									if ((x + i)->Get_MaHopDong() == ma) {
										find = true;
										int tt3 = 0;
										int* mau = new int[10];
										for (int i = 0; i < 5; i++) {
											mau[i] = Mauchu;
										}
										mau[0] = Maunen;
										while (1) {
											clrscr();
											gotoXY(50, 2);
											TextColor(132);
											cout << "=== Hop Dong " << ma << " ===" << endl;
											int line = 4;
											for (int i = 0; i < 5; i++) {
												TextColor(mau[i]);
												gotoXY(52, line);
												cout << thaotac3[i] << endl;
												line = line + 2;
											}
											int z = _getch();
											TRANGTHAI trangthai3 = key(z);
											switch (trangthai3) {
											case UP:
												if (tt3 == 0) {
													tt3 = 4;
												}
												else {
													tt3--;
												}
												break;
											case DOWN:
												if (tt3 == 4) {
													tt3 = 0;
												}
												else {
													tt3++;
												}
												break;
											case ENTER:
												if (tt3 == 0) {
													clrscr();
													system("color 80");
													gotoXY(50, 2);
													TextColor(132);
													cout << "=== Sua ten nguoi mua ===" << endl;
													TextColor(135);
													string name1;
													gotoXY(52, 4);
													cout << "Ten nguoi mua cu: " << (x + i)->Get_NguoiMua() << endl;
													gotoXY(52, 5);
													cout << "Nhap ten nguoi mua moi: ";
													getline(cin, name1);
													/*truyền name1 vừa nhập vào để gán cho thuộc tính NguoiMua*/
													(x + i)->Set_NguoiMua(name1);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua ten nguoi mua!" << endl;
													system("pause");
												}
												if (tt3 == 1) {
													clrscr();
													system("color 80");
													gotoXY(50, 2);
													TextColor(132);
													cout << "=== Sua ten nguoi thu huong ===" << endl;
													TextColor(135);
													string name2;
													gotoXY(52, 4);
													cout << "Ten nguoi thu huong cu: " << (x + i)->Get_NguoiThuHuong() << endl;
													gotoXY(52, 5);
													cout << "Nhap ten nguoi thu huong moi: ";
													getline(cin, name2);
													//truyền name2 vừa nhập vào để gán cho thuộc tính NguoiThuHuong
													(x + i)->Set_NguoiThuHuong(name2);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua ten nguoi thu huong!" << endl;
													system("pause");
												}
												if (tt3 == 2) {
													clrscr();
													gotoXY(50, 2);
													system("color 80");
													TextColor(132);
													cout << "=== Sua gia tri hop dong ===" << endl;
													TextColor(135);
													float giatri;
													gotoXY(52, 4);
													cout << "Gia tri hop dong cu: " << (size_t)(x + i)->Get_GiaTriHopDong() << endl;
													gotoXY(52, 5);
													cout << "Nhap gia tri hop dong moi: ";
													cin >> giatri;
													//Truyền giatri vào để gán cho thuộc tính GiaTriHopDong
													(x + i)->Set_GiaTriHopDong(giatri);
													//Giá trị hợp đồng thay đổi thì Tiền giữ lại cũng thay đổi
													(x + i)->Set_TienGiuLai();
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua gia tri hop dong!" << endl;
													cin.ignore();
													system("pause");
												}
												if (tt3 == 3) {
													clrscr();
													gotoXY(50, 2);
													system("color 80");
													TextColor(132);
													cout << "=== Sua thoi han hop dong ===" << endl;
													TextColor(135);
													float nam;
													gotoXY(52, 4);
													cout << "Thoi han hop dong cu: " << (x + i)->Get_ThoiHan() << endl;
													gotoXY(52, 5);
													cout << "Nhap thoi han hop dong moi: ";
													cin >> nam;
													//truyền nam vào để gán cho thuộc tính ThoiHan
													(x + i)->Set_ThoiHan(nam);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua thoi han hop dong!" << endl;
													cin.ignore();
													system("pause");
												}
												if (tt3 == 4) {
													goto ghi;
												}

											}
											for (int i = 0; i < 5; i++)
												mau[i] = Mauchu;
											mau[tt3] = Maunen;
										}
									}
								}
							}
							//Tương tự với ma[0]='C'
							if (ma[0] == 'N') {
								for (int i = 0; i < n; i++) {
									if ((y + i)->Get_MaHopDong() == ma) {
										find = true;
										int tt3 = 0;
										int* mau = new int[10];
										for (int i = 0; i < 5; i++) {
											mau[i] = Mauchu;
										}
										mau[0] = Maunen;
										while (1) {
											clrscr();
											gotoXY(50, 2);
											TextColor(132);
											cout << "=== Hop Dong " << ma << " ===" << endl;
											int line = 4;
											for (int i = 0; i < 5; i++) {
												TextColor(mau[i]);
												gotoXY(52, line);
												cout << thaotac3[i] << endl;
												line = line + 2;
											}
											int z = _getch();
											TRANGTHAI trangthai3 = key(z);
											switch (trangthai3) {
											case UP:
												if (tt3 == 0) {
													tt3 = 4;
												}
												else {
													tt3--;
												}
												break;
											case DOWN:
												if (tt3 == 4) {
													tt3 = 0;
												}
												else {
													tt3++;
												}
												break;
											case ENTER:
												if (tt3 == 0) {
													clrscr();
													system("color 80");
													gotoXY(50, 2);
													TextColor(132);
													cout << "=== Sua ten nguoi mua ===" << endl;
													TextColor(135);
													string name1;
													gotoXY(52, 4);
													cout << "Ten nguoi mua cu: " << (y + i)->Get_NguoiMua() << endl;
													gotoXY(52, 5);
													cout << "Nhap ten nguoi mua moi: ";
													getline(cin, name1);
													(y + i)->Set_NguoiMua(name1);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua ten nguoi mua!" << endl;
													system("pause");
												}
												if (tt3 == 1) {
													clrscr();
													system("color 80");
													gotoXY(50, 2);
													TextColor(132);
													cout << "=== Sua ten nguoi thu huong ===" << endl;
													TextColor(135);
													string name2;
													gotoXY(52, 4);
													cout << "Ten nguoi thu huong cu: " << (y + i)->Get_NguoiThuHuong() << endl;
													gotoXY(52, 5);
													cout << "Nhap ten nguoi thu huong moi: ";
													getline(cin, name2);
													(y + i)->Set_NguoiThuHuong(name2);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua ten nguoi thu huong!" << endl;
													system("pause");
												}
												if (tt3 == 2) {
													clrscr();
													gotoXY(50, 2);
													system("color 80");
													TextColor(132);
													cout << "=== Sua gia tri hop dong ===" << endl;
													TextColor(135);
													float giatri;
													gotoXY(52, 4);
													cout << "Gia tri hop dong cu: " << (size_t)(y + i)->Get_GiaTriHopDong() << endl;
													gotoXY(52, 5);
													cout << "Nhap gia tri hop dong moi: ";
													cin >> giatri;
													(y + i)->Set_GiaTriHopDong(giatri);
													(y + i)->Set_TienGiuLai();
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua gia tri hop dong!" << endl;
													cin.ignore();
													system("pause");
												}
												if (tt3 == 3) {
													clrscr();
													gotoXY(50, 2);
													system("color 80");
													TextColor(132);
													cout << "=== Sua thoi han hop dong ===" << endl;
													TextColor(135);
													float nam;
													gotoXY(52, 4);
													cout << "Thoi han hop dong cu: " << (y + i)->Get_ThoiHan() << endl;
													gotoXY(52, 5);
													cout << "Nhap thoi han hop dong moi: ";
													cin >> nam;
													(y + i)->Set_ThoiHan(nam);
													gotoXY(52, 7);
													TextColor(138);
													cout << "Da sua thoi han hop dong!" << endl;
													cin.ignore();
													system("pause");
												}
												if (tt3 == 4) {
													goto ghi;
												}

											}
											for (int i = 0; i < 5; i++)
												mau[i] = Mauchu;
											mau[tt3] = Maunen;
										}
									}
								}
							}
							/*Sau khi thực hiện xong các lệnh bên trên mà find == false tức là không tìm
							thấy hợp đồng nào trùng khớp với ma*/
							if (find == false) {
								gotoXY(45, 5);
								TextColor(132);
								cout << "Khong tim thay hop dong trung khop!";
								int tt6 = 0;
								int* mau = new int[2];
								for (int i = 0; i < 2; i++)
									mau[i] = Mauchu;
								mau[0] = Maunen;
								while (1) {
									int row = 47;
									for (int i = 0; i < 2; i++) {
										TextColor(mau[i]);
										gotoXY(row, 7);
										cout << thaotac6[i] << endl;
										row = row + 20;
									}
									int z = _getch();
									TRANGTHAI trangthai6 = key(z);
									switch (trangthai6) {
									case LEFT:
										if (tt6 == 0) {
											tt6 = 1;
										}
										else {
											tt6--;
										}
										break;
									case RIGHT:
										if (tt6 == 1) {
											tt6 = 0;
										}
										else {
											tt6++;
										}
										break;
									case ENTER:
										if (tt6 == 0) {
											goto nhapma1;
										}
										if (tt6 == 1) {
											goto back2;
										}
									}
									for (int i = 0; i < 2; i++)
										mau[i] = Mauchu;
									mau[tt6] = Maunen;
								}
							}
							/*Sau khi sửa xong thì sẽ cần lưu lại dữ liệu đã thay đổi đó vào lại file*/
						ghi:
							system("color 80");
							fstream file;
							file.open("ds.txt", ios_base::out);
							file << n << endl;
							for (int i = 0; i < n; i++) {
								/*Nếu là hợp đồng cơ bản thì sẽ dùng dữ liệu trong x để ghi vào file, 
								nếu là hợp đồng nâng cao sẽ dùng dữ liệu trong y để ghi*/
								if (danhsach[i]->Get_MaHopDong()[0] == 'C') {
									file << (x + i)->Get_MaHopDong() << ", ";
									file << (x + i)->Get_NguoiMua() << ", ";
									file << (x + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(x + i)->Get_GiaTriHopDong() << ", ";
									file << (x + i)->Get_ThoiHan() << ", ";
									file << (x + i)->Get_ngaynhap() << " ";
									file << (x + i)->Get_hoahong() << ", ";
									file << (size_t)(x + i)->Get_TienGiuLai() << endl;
								}
								if (danhsach[i]->Get_MaHopDong()[0] == 'N') {
									file << (y + i)->Get_MaHopDong() << ", ";
									file << (y + i)->Get_NguoiMua() << ", ";
									file << (y + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(y + i)->Get_GiaTriHopDong() << ", ";
									file << (y + i)->Get_ThoiHan() << ", ";
									file << (y + i)->Get_ngaynhap() << " ";
									file << (y + i)->Get_hoahong() << ", ";
									file << (size_t)(y + i)->Get_TienGiuLai() << endl;
								}
							}
							goto back2;
							delete[]x;
							delete[]y;
							file.close();
							system("pause");
						}
						if (tt2 == 1) {
							/*Phần đọc dữ liệu từ file vào chương trình này tương tự với phần sửa hợp đồng bên trên*/
							int n;
							XuatHopDong* danhsach[100];
							Read(danhsach, n);
							ifstream filein;
							filein.open("ds.txt", ios_base::in);
							filein >> n;
							HopDongCoBan* x;
							HopDongNangCao* y;
							x = new HopDongCoBan[n];
							y = new HopDongNangCao[n];
							for (int i = 0; i < n; i++) {
								char c;
								filein >> c;
								filein.seekg(-1, 1);
								if (c == 'C') {
									(x + i)->Read_filein(filein);
								}
								else if (c == 'N') {
									(y + i)->Read_filein(filein);
								}
							}
							filein.close();
							int m, l;
						nhapma:
							system("cls");
							bool check = false;
							gotoXY(50, 2);
							TextColor(132);
							cout << "=== Xoa hop dong ===" << endl;
							gotoXY(46, 3);
							TextColor(135);
							cout << "Nhap ma hop dong can xoa: ";
							string ma;
							getline(cin, ma);
							for (int i = 0; i < 2; i++) {
								if ('a' <= ma[i] && ma[i] <= 'z') {
									ma[i] = ma[i] - 32;
								}
							}
							for (int i = 0; i < n; i++) {
								if (danhsach[i]->Get_MaHopDong() == ma) {
									/*để không làm ảnh hưởng đến n (chỉ số hợp đồng có trong file),
									gán n cho l*/
									m = i;
									l = n - 1;
									check = true;
								}
							}
							/*check == false tức là không có hợp đồng nào trùng khớp với mã đã nhập*/
							if (check == false) {
								gotoXY(45, 5);
								TextColor(132);
								cout << "Khong tim thay hop dong trung khop!";
								gotoXY(45, 6);
								int tt7 = 0;
								int* mau = new int[2];
								for (int i = 0; i < 2; i++)
									mau[i] = Mauchu;
								mau[0] = Maunen;
								while (1) {
									int row = 47;
									for (int i = 0; i < 2; i++) {
										TextColor(mau[i]);
										gotoXY(row, 7);
										cout << thaotac6[i] << endl;
										row = row + 20;
									}
									int z = _getch();
									TRANGTHAI trangthai6 = key(z);
									switch (trangthai6) {
									case LEFT:
										if (tt7 == 0) {
											tt7 = 1;
										}
										else {
											tt7--;
										}
										break;
									case RIGHT:
										if (tt7 == 1) {
											tt7 = 0;
										}
										else {
											tt7++;
										}
										break;
									case ENTER:
										if (tt7 == 0) {
											goto nhapma;
										}
										if (tt7 == 1) {
											goto back2;
										}
									}
									for (int i = 0; i < 2; i++)
										mau[i] = Mauchu;
									mau[tt7] = Maunen;
								}
							}
							if (check == true) {
								gotoXY(42, 5);
								TextColor(138);
								cout << "Hop dong " << ma << " da duoc xoa thanh cong!" << endl;
							}
							/*Sau khi chọn được hợp đồng cần xoá thì sẽ tiến hành ghi lại file*/
							fstream file;
							file.open("ds.txt", ios_base::out);
							file << l << endl;
							/*Xoá hợp đồng là khi ghi file sẽ bỏ qua hợp đồng cần xoá (Nhận biết nhờ đã gán i cho m ở trên)
							chỉ ghi những hợp đồng còn lại.
							Ví dụ: dãy 1, 2, 3, 4, 5. Muốn xoá 3 thì chỉ ghi 1, 2, bỏ qua ghi 3, ghi tiếp 4, 5 =))*/
							for (int i = 0; i < m; i++) {
								if (danhsach[i]->Get_MaHopDong()[0] == 'C') {
									file << (x + i)->Get_MaHopDong() << ", ";
									file << (x + i)->Get_NguoiMua() << ", ";
									file << (x + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(x + i)->Get_GiaTriHopDong() << ", ";
									file << (x + i)->Get_ThoiHan() << ", ";
									file << (x + i)->Get_ngaynhap() << " ";
									file << (x + i)->Get_hoahong() << ", ";
									file << (size_t)(x + i)->Get_TienGiuLai() << endl;
								}
								if (danhsach[i]->Get_MaHopDong()[0] == 'N') {
									file << (y + i)->Get_MaHopDong() << ", ";
									file << (y + i)->Get_NguoiMua() << ", ";
									file << (y + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(y + i)->Get_GiaTriHopDong() << ", ";
									file << (y + i)->Get_ThoiHan() << ", ";
									file << (y + i)->Get_ngaynhap() << " ";
									file << (y + i)->Get_hoahong() << ", ";
									file << (size_t)(y + i)->Get_TienGiuLai() << endl;
								}
							}
							for (int i = m + 1; i < n; i++) {
								if (danhsach[i]->Get_MaHopDong()[0] == 'C') {
									file << (x + i)->Get_MaHopDong() << ", ";
									file << (x + i)->Get_NguoiMua() << ", ";
									file << (x + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(x + i)->Get_GiaTriHopDong() << ", ";
									file << (x + i)->Get_ThoiHan() << ", ";
									file << (x + i)->Get_ngaynhap() << " ";
									file << (x + i)->Get_hoahong() << ", ";
									file << (size_t)(x + i)->Get_TienGiuLai() << endl;
								}
								if (danhsach[i]->Get_MaHopDong()[0] == 'N') {
									file << (y + i)->Get_MaHopDong() << ", ";
									file << (y + i)->Get_NguoiMua() << ", ";
									file << (y + i)->Get_NguoiThuHuong() << ", ";
									file << (size_t)(y + i)->Get_GiaTriHopDong() << ", ";
									file << (y + i)->Get_ThoiHan() << ", ";
									file << (y + i)->Get_ngaynhap() << " ";
									file << (y + i)->Get_hoahong() << ", ";
									file << (size_t)(y + i)->Get_TienGiuLai() << endl;
								}
							}
							delete[]x;
							delete[]y;
							file.close();
							system("pause");
						}
						if (tt2 == 2) {
							system("cls");
							float cb, nc;
							gotoXY(50, 2);
							TextColor(132);
							cout << "=== Sua % hoa hong ===";
							TextColor(135);
							gotoXY(50, 4);
							CB.Set_hoahong();
							NC.Set_hoahong();
							cout << "% Hop dong co ban cu: " << CB.Get_hoahong();
							gotoXY(50, 5);
							cout << "% hop dong co ban moi: ";
							cin >> cb;
							gotoXY(50, 6);
							cout << "% Hop dong nang cao cu: " << NC.Get_hoahong();
							gotoXY(50, 7);
							cout << "% Hop dong nang cao moi: ";
							cin >> nc;
							/*ở ngay đầu phần Menu đã khai báo đối tượng tương ứng của hợp đồng cơ bản và nâng cao
							sau khi nhập xong h% mới sẽ tiến hành gán lại*/
							CB.a = cb;
							NC.b = nc;
							gotoXY(50, 9);
							TextColor(138);
							cout << "Da sua % hoa hong!" << endl << endl;
							cin.ignore();
							system("pause");
						}
						if (tt2 == 3) {
							goto back;
						}
					}
					for (int i = 0; i < 4; i++)
						mau[i] = Mauchu;
					mau[tt2] = Maunen;
				}
			}
			//5. Tìm kiếm hợp đồng (NGA + HIẾU)
			if (tt == 4) {
				/*Lệnh if này để kiểm tra xem hợp đồng đã được xuất hay chưa.
				Nếu trước khi thực hiện lệnh này hợp đồng chưa được xuất, tức là chưa ghi dữ liệu
				từ file vào chương trình, value là false thì sẽ tiến hành đọc file để ghi dữ liệu
				từ file vào chương trình nhờ phương thức Read*/
				if (value) {
					Read(ds, n);
					value = false;
				}
			nhapngay1:
				system("cls");
				gotoXY(50, 2);
				TextColor(132);
				cout << "=== Tim kiem hop dong ===";
				string thoigian1, thoigian2;
				TextColor(135);
				gotoXY(48, 4);
				cout << "Nhap khoang thoi gian can tim: ";
				gotoXY(55, 5);
				cout << "Tu: ";
				getline(cin, thoigian1);
				cout << endl;
				gotoXY(55, 6);
				cout << "Den: ";
				getline(cin, thoigian2);
				cout << endl;
				int dem = 0;
				/*Gọi phương thức Set_Date rồi gán vào các date*/
				int date1 = Set_Date(thoigian1);
				int date2 = Set_Date(thoigian2);
				/*Không thể nhập khoảng thời gian cần xét Từ: 25/09/2023 Đến: 25/09/2003*/
				if (date2 < date1) {
					TextColor(132);
					gotoXY(54, 8);
					cout << "NGAY KHONG HOP LE!";
					int tt8 = 0;
					int* mau = new int[2];
					for (int i = 0; i < 2; i++)
						mau[i] = Mauchu;
					mau[0] = Maunen;
					while (1) {
						int row = 50;
						for (int i = 0; i < 2; i++) {
							TextColor(mau[i]);
							gotoXY(row, 10);
							cout << thaotac6[i] << endl;
							row = row + 20;
						}
						int z = _getch();
						TRANGTHAI trangthai6 = key(z);
						switch (trangthai6) {
						case LEFT:
							if (tt8 == 0) {
								tt8 = 1;
							}
							else {
								tt8--;
							}
							break;
						case RIGHT:
							if (tt8 == 1) {
								tt8 = 0;
							}
							else {
								tt8++;
							}
							break;
						case ENTER:
							if (tt8 == 0) {
								goto nhapngay1;
							}
							if (tt8 == 1) {
								goto back;
							}
						}
						for (int i = 0; i < 2; i++)
							mau[i] = Mauchu;
						mau[tt8] = Maunen;
					}
				}
				cout << "Ma hop dong" << "|" << " Ten nguoi mua " << "|" << " Ten nguoi thu huong " << "|" << "Gia tri hop dong" << "|" << "Ngay nhap hop dong" << "|" << "Thoi han hop dong" << "|" << "% hoa hong" << "|" << "Tien duoc giu lai" << endl;
				for (int i = 0; i < 126; i++) {
					cout << "_";
					if (i == 10 || i == 25 || i == 46 || i == 62 || i == 80 || i == 97 || i == 107) {
						cout << "|";
					}
				}
				cout << endl;
				for (int i = 0; i < n; i++) {
					int date = Set_Date(ds[i]->Get_ngaynhap());
					/*Ví dụ: xét Từ 21/03/2003 Đến 25/09/2023 thì sẽ đổi thành 20030321<x<20230925
					vậy thì hợp đồng được nhập vào ngày 25/09/2003 là 20030925 sẽ nằm trong khoảng đó =>Xuất hợp đồng đó ra*/
					if (date1 <= date && date <= date2) {
						ds[i]->Xuat();
						dem++;
					}
				}
				if (dem == 0) {
					gotoXY(41, 10);
					TextColor(132);
					cout << "KHONG CO HOP DONG NAO TRONG KHOANG THOI GIAN NAY!" << endl << endl;
				}
				system("pause");
			}
			//6. Tính số tiền công ty thu nhận (NGA + HIẾU)
			if (tt == 5) {
				/*Lệnh if này để kiểm tra xem hợp đồng đã được xuất hay chưa.
				Nếu trước khi thực hiện lệnh này hợp đồng chưa được xuất, tức là chưa ghi dữ liệu
				từ file vào chương trình, value là false thì sẽ tiến hành đọc file để ghi dữ liệu
				từ file vào chương trình nhờ phương thức Read*/
				if (value) {
					Read(ds, n);
					value = false;
				}
			nhapngay2:
				system("cls");
				float sum = 0;
				gotoXY(50, 2);
				TextColor(132);
				cout << "=== Tinh so tien cong ty thu nhan ===" << endl;
				string thoigian1, thoigian2;
				TextColor(135);
				gotoXY(51, 4);
				cout << "Nhap vao khoang thoi gian can tim: " << endl;
				gotoXY(60, 5);
				cout << "Tu: ";
				getline(cin, thoigian1);
				gotoXY(60, 6);
				cout << "Den: ";
				getline(cin, thoigian2);
				cout << endl;
				int dem = 0;
				int date1 = Set_Date(thoigian1);
				int date2 = Set_Date(thoigian2);
				if (date2 < date1) {
					TextColor(132);
					gotoXY(58, 8);
					cout << "NGAY KHONG HOP LE!";
					int tt9 = 0;
					int* mau = new int[2];
					for (int i = 0; i < 2; i++)
						mau[i] = Mauchu;
					mau[0] = Maunen;
					while (1) {
						int row = 54;
						for (int i = 0; i < 2; i++) {
							TextColor(mau[i]);
							gotoXY(row, 10);
							cout << thaotac6[i] << endl;
							row = row + 20;
						}
						int z = _getch();
						TRANGTHAI trangthai6 = key(z);
						switch (trangthai6) {
						case LEFT:
							if (tt9 == 0) {
								tt9 = 1;
							}
							else {
								tt9--;
							}
							break;
						case RIGHT:
							if (tt9 == 1) {
								tt9 = 0;
							}
							else {
								tt9++;
							}
							break;
						case ENTER:
							if (tt9 == 0) {
								goto nhapngay2;
							}
							if (tt9 == 1) {
								goto back;
							}
						}
						for (int i = 0; i < 2; i++)
							mau[i] = Mauchu;
						mau[tt9] = Maunen;
					}
				}
				/*Vì phần này cần xét đến TienGiuLai, mà XuatHopDong không có, nên cần gọi các lớp dẫn xuất
				để ghi dữ liệu về TienGiuLai vào*/
				int d;
				ifstream fileout;
				fileout.open("ds.txt", ios_base::in);
				fileout >> d;
				HopDongCoBan* x;
				HopDongNangCao* y;
				x = new HopDongCoBan[d];
				y = new HopDongNangCao[d];
				for (int i = 0; i < n; i++) {
					char c;
					fileout >> c;
					fileout.seekg(-1, 1);
					if (c == 'C') {
						(x + i)->Read_filein(fileout);
					}
					else if (c == 'N') {
						(y + i)->Read_filein(fileout);
					}
				}
				fileout.close();
				bool find = false;
				for (int i = 0; i < n; i++) {
					int date = Set_Date(ds[i]->Get_ngaynhap());
					if (date1 <= date && date <= date2) {
						find = true;
						/*Nếu hợp đồng đó là cơ bản thì dùng dữ liệu TienGiuLai trong x,
						còn nếu là hợp đồng nâng cao thì dùng dữ liệu TienGiuLai trong y*/
						if (ds[i]->Get_MaHopDong()[0] == 'C') {
							sum += (x + i)->Get_TienGiuLai();
						}
						if (ds[i]->Get_MaHopDong()[0] == 'N') {
							sum += (y + i)->Get_TienGiuLai();
						}
					}
				}
				delete[]x;
				delete[]y;
				if (find == false) {
					gotoXY(50, 7);
					TextColor(132);
					cout << "KHONG CO HOP DONG NAO TRONG KHOANG THOI GIAN NAY!";
				}
				else {
					gotoXY(43, 8);
					TextColor(138);
					cout << "Tien cong ty thu nhan do ban bao hiem la: " << (size_t)sum << endl;
				}
				system("pause");
			}
			//7. Đóng chương trình (HIẾU)
			if (tt == 6) {
				clrscr();
				system("color 80");
				gotoXY(50, 2);
				TextColor(132);
				cout << "Ban co chac chan muon dong chuong trinh?";
				TextColor(135);
				int tt5 = 0;
				int* mau = new int[2];
				for (int i = 0; i < 2; i++)
					mau[i] = Mauchu;
				mau[0] = Maunen;
				while (1) {
					int line = 4;
					for (int i = 0; i < 2; i++) {
						TextColor(mau[i]);
						gotoXY(69, line);
						cout << thaotac5[i] << endl;
						line = line + 2;
					}
					int z = _getch();
					TRANGTHAI trangthai4 = key(z);
					switch (trangthai4) {
					case UP:
						if (tt5 == 0) {
							tt5 = 1;
						}
						else {
							tt5--;
						}
						break;
					case DOWN:
						if (tt5 == 1) {
							tt5 = 0;
						}
						else {
							tt5++;
						}
						break;
					case ENTER:
						if (tt5 == 0) {
							system("cls");
							system("color 07");
							exit(0);
						}
						if (tt5 == 1) {
							goto back;
						}
					}
					for (int i = 0; i < 2; i++)
						mau[i] = Mauchu;
					mau[tt5] = Maunen;
				}
			}
		}
		for (int i = 0; i < 7; i++)
			mau[i] = Mauchu;
		mau[tt] = Maunen;
	}
}