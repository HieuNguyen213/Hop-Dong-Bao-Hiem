﻿//HIẾU
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
#include<math.h>
using namespace std;
class XuatHopDong {
protected:
	int ngay, thang, nam;
	string MaHopDong;
	string NguoiMua, NguoiThuHuong;
	float GiaTriHopDong;
	float hoahong;
	string ngaynhap;
	int ThoiHan;
public:
	void Set_MaHopDong(string);
	string Get_MaHopDong();
	void Set_NguoiMua(string);
	string Get_NguoiMua();
	void Set_NguoiThuHuong(string);
	string Get_NguoiThuHuong();
	void Set_GiaTriHopDong(float);
	float Get_GiaTriHopDong();
	void Set_hoahong(float);
	float Get_hoahong();
	void Set_ngaynhap(string);
	string Get_ngaynhap();
	void Set_ThoiHan(int);
	int Get_ThoiHan();
	virtual void Read_filein(ifstream&);
	virtual void Xuat();
};

class HopDongCoBan : public XuatHopDong {
private:
	float TienGiuLai;
public:
	void Set_TienGiuLai();
	float Get_TienGiuLai();
	void Read_filein(ifstream&);
	void Xuat();
	~HopDongCoBan();
};

class HopDongNangCao : public XuatHopDong {
private:
	float TienGiuLai;
public:
	void Set_TienGiuLai();
	float Get_TienGiuLai();
	void Read_filein(ifstream&);
	void Xuat();
	~HopDongNangCao();
};

