#include"NhapHopDong.h"
#include"XuatHopDong.h"
#include"Console.h"
#include<iostream>
using namespace std;
class Function
{
public:
	void Save();
	void Read(XuatHopDong* ds[], int& n);
	void Add(int& n);
	friend int Set_Date(string comp);
	void Menu();
};


