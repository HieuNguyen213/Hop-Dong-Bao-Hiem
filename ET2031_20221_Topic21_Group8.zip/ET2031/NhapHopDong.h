//NGA
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
#include<math.h>
#include"Console.h"
using namespace std;
class NhapHopDong {
protected:
	string MaHopDong;
	string NguoiMua, NguoiThuHuong;
	float GiaTriHopDong;
	string ngaynhap;
	int ThoiHan;
public:
	string Get_MaHopDong();
	NhapHopDong();
	~NhapHopDong();
	void Nhap();
	static float a;
	static float b;
};

class HopDongCoBan1 : public NhapHopDong {
private: 
	float hoahong;
	float TienGiuLai;
public:
	HopDongCoBan1();
	~HopDongCoBan1();
	void Nhap();
	void Set_hoahong();
	void Set_hoahong(float);
	float Get_hoahong();
	void Set_TienGiuLai();
	friend istream& operator>>(istream&, HopDongCoBan1&);
	friend ostream& operator<<(ostream&, HopDongCoBan1);
};

class HopDongNangCao1 : public NhapHopDong {
private:
	float hoahong;
	float TienGiuLai;
public:
	HopDongNangCao1();
	~HopDongNangCao1();
	void Nhap();
	void Set_hoahong();
	void Set_hoahong(float);
	float Get_hoahong();
	void Set_TienGiuLai();
	friend istream& operator>>(istream&, HopDongNangCao1&);
	friend ostream& operator<<(ostream&, HopDongNangCao1);
};
