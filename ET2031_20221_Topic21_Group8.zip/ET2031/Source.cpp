#include"Function.h"
#define TUONG_TREN 2
#define TUONG_DUOI 30
#define TUONG_PHAI 90
#define TUONG_TRAI 20
int main() {
	system("color 80");
	gotoXY(50, 2);
	TextColor(132);
	cout << "TRUONG DAI HOC BACH KHOA HA NOI" << endl;
	gotoXY(54, 3);
	cout << "VIEN DIEN TU VIEN THONG" << endl;
	gotoXY(56, 8);
	TextColor(135);
	cout << "BAO CAO BAI TAP LON" << endl;
	gotoXY(51, 9);
	cout << "MON KY THUAT LAP TRINH C/C++" << endl;
	gotoXY(46, 10);
	cout << "chuong trinh quan ly hop dong bao hiem" << endl;
	gotoXY(43, 14);
	TextColor(140);
	cout << "Sinh vien thuc hien: " << "Mac Phuong Nga - 20210636" << endl;
	gotoXY(64, 15);
	cout << "Nguyen Thac Hieu - 20213921" << endl;
	gotoXY(55, 17);
	TextColor(134);
	cout << "Loading";
	char c;
	int dem = 0;
	while (dem < 4) {
		gotoXY(62, 17);
		for (int i = 0; i < 8; i++) {
			cout << ".";
			Sleep(130);
		}
		gotoXY(62, 17);
		for (int i = 7; i >= 0; i--) {
			cout << " ";
		}
		dem++;
	}
	cout << endl;
	Function f;
	f.Menu();
	return 0;
}